#!/bin/bash

echo "Hello Linux"

date
